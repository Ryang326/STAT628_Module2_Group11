library(shiny)
library(tidyverse)
library(shinythemes)
library(flexdashboard)
library(caret)
load("BFmodels.Rda")

wrist_low <- 15
wrist_up <- 21
height_low <- 100
height_up <- 200
abdomen_low <- 70
abdomen_up <- 120
age_low <- 20
age_up <- 100


server <- function(input, output, session) {
  

  
  user_input <- eventReactive(input$calculate,{
    validate(
      need(input$age, "Please enter your age!"),
      need(input$age <= age_up & input$age >= age_low,
           paste0("AGE is out of range: [",age_low,", ",age_up,"].\n")),
      need(input$height, "Please enter your height!"),
      if(input$height_unit == "cm"){need(input$height <= height_up & input$height >= height_low,
                                         paste0("HEIGHT is out of range: [",height_low,"cm, ",height_up,"cm].\n"))}else{
                                           need(input$height <= height_up/2.54 & input$height >= height_low/2.54,
                                                paste0("HEIGHT is out of range: [",round(height_low/2.54,2)," inches, ",round(height_up/2.54,2)-0.01," inches].\n"))
                                           
                                         },
      need(input$abdomen, "Please enter your abdomen!"),
      if(input$abdomen_unit == "cm"){need(input$abdomen <= abdomen_up & input$abdomen >= abdomen_low,
                                          paste0("ABDOMEN is out of range: [",abdomen_low,"cm, ",abdomen_up,"cm].\n"))}else{
                                            need(input$abdomen <= abdomen_up/2.54 & input$abdomen >= abdomen_low/2.54,
                                                 paste0("ABDOMEN is out of range: [",round(abdomen_low/2.54,2)," inches, ",round(abdomen_up/2.54,2)-0.01," inches].\n"))
                                          },
      if(!is.na(input$wrist)){if(input$wrist_unit == "cm"){need((input$wrist <= wrist_up & input$wrist >= wrist_low),
                                                                paste0("WRIST is out of range: [",wrist_low,"cm, ",wrist_up,"cm].\n"))}else{
                                                                  need((input$wrist <= wrist_up/2.54 & input$wrist >= wrist_low/2.54),
                                                                       paste0("WRIST is out of range: [",round(wrist_low/2.54,2)," inches, ",round(wrist_up/2.54,2)-0.01," inches].\n"))
                                                                }}
    )
    a <- vector(mode = "list",4)
    a$abdomen <- input$abdomen*ifelse(input$abdomen_unit == "cm",1,2.54)
    a$height <- input$height*ifelse(input$height_unit == "cm",1,2.54)
    a$wrist <- input$wrist*ifelse(input$wrist_unit == "cm",1,2.54)
    if(input$age <= 40){
      a$age <- 1
    }else{
      a$age <- 2
    }
    a
    })
    
  user_bodyfat <- eventReactive(user_input(),{
    user <- user_input()
    
    
    if(is.na(user$wrist) == T){
      new_data <- tibble(HEIGHT = user$height,
                             ABDOMEN = user$abdomen,
                             `AGEgroup(40,80]` = 0
                             )
      if(user$age == 2){
        new_data$`AGEgroup(40,80]` <- 1
      }
      bodyfat <- predict(mod1_wot_wrist,new_data)
    }
    if(is.na(user$wrist) == F){
      new_data <- tibble(HEIGHT = user$height,
                             ABDOMEN = user$abdomen,
                             WRIST = user$wrist,
                             `AGEgroup(40,80]` = 0
                             )
      if(user$age == 2){
        new_data$`AGEgroup(40,80]`[1] <- 1
      }
      bodyfat <- predict(mod2_wth_wrist,new_data)
    }
    as.numeric(bodyfat) %>% round(2)
  })
  
  output$text1 <- renderText({
    validate(need(input$age & input$height & input$abdomen,"Please complete your input!"))
    validate(need(user_bodyfat()>=3, "Does this person really exist? Check your input!"))
    
    HTML(paste0('Your body fat percentage is ',user_bodyfat(), "%."))
  
  
  })
  
  output$text2 <- renderText({
    validate(need(input$age & input$height & input$abdomen,"You need to input your age, height and abodomen at least."))
    validate(need(user_bodyfat()>=3,"The minimal body fat should be above 3%."))
    HTML(paste0("Level of Body Fat: ",
    ifelse(user_bodyfat()<=5,"Essential Fat.",
           ifelse(user_bodyfat()<=13, "Athletes",
                  ifelse(user_bodyfat()<=17, "Fitness",
                         ifelse(user_bodyfat()<25,"Average","Obese"
                         )
                  )
           ))
    ))})
  
  output$gauge <- renderGauge({
    validate(
      need(input$age, "Please enter your age!"),
      need(input$age <= age_up & input$age >= age_low,
           paste0("AGE is out of range: [",age_low,", ",age_up,"].\n")),
      need(input$height, "Please enter your height!"),
      if(input$height_unit == "cm"){need(input$height <= height_up & input$height >= height_low,
                                         paste0("HEIGHT is out of range: [",height_low,"cm, ",height_up,"cm].\n"))}else{
                                           need(input$height <= height_up/2.54 & input$height >= height_low/2.54,
                                                paste0("HEIGHT is out of range: [",round(height_low/2.54,2)," inches, ",round(height_up/2.54,2)-0.01," inches].\n"))
                                           
                                         },
      need(input$abdomen, "Please enter your abdomen!"),
      if(input$abdomen_unit == "cm"){need(input$abdomen <= abdomen_up & input$abdomen >= abdomen_low,
                                          paste0("ABDOMEN is out of range: [",abdomen_low,"cm, ",abdomen_up,"cm].\n"))}else{
                                            need(input$abdomen <= abdomen_up/2.54 & input$abdomen >= abdomen_low/2.54,
                                                 paste0("ABDOMEN is out of range: [",round(abdomen_low/2.54,2)," inches, ",round(abdomen_up/2.54,2)-0.01," inches].\n"))
                                          },
      if(!is.na(input$wrist)){if(input$wrist_unit == "cm"){need((input$wrist <= wrist_up & input$wrist >= wrist_low),
                                                                paste0("WRIST is out of range: [",wrist_low,"cm, ",wrist_up,"cm].\n"))}else{
                                                                  need((input$wrist <= wrist_up/2.54 & input$wrist >= wrist_low/2.54),
                                                                       paste0("WRIST is out of range: [",round(wrist_low/2.54,2)," inches, ",round(wrist_up/2.54,2)-0.01," inches].\n"))
                                                                }}
      )
    gauge(user_bodyfat(),min = 0, max = 40, 
          sectors = gaugeSectors(c(10,25),c(0,10),c(25,30)),
          symbol = "%", label = "BODYFAT")
  })
  
  output$comparison <- renderImage({
    
    validate(need(input$age & input$height & input$abdomen,""))
    validate(need(user_bodyfat()>=3,""))
    
    
    if(user_bodyfat()<=10){
      pic <-  "under10.jpeg"
    } 
    if(user_bodyfat() <= 14 & user_bodyfat() >10){
      pic <- "10-14.jpeg"
    }
    if(user_bodyfat() <= 20 & user_bodyfat() >14){
      pic <-  "15-20.jpeg"
    }
    if(user_bodyfat() <= 30 & user_bodyfat() > 20){
      pic <-  "21-30.jpeg"
    } 
    if(user_bodyfat() > 30){
      pic <-  "over30.jpeg"
    }
    list(src = paste0("www/",pic))
  
  },deleteFile = F)
  
  output$contact <- renderUI({
    email <- a("txu98@wisc.edu",href = "txu98@wisc.edu")
    link <- a("GitHub link to this project",href = "https://github.com/Ryang326/STAT628_Module2_Group11")
    tagList(HTML(paste("If you have further questions about this shiny app,","please contact us for details.<br/>",sep = "<br/>")),
            HTML("Email: Tinghui Xu "),email,
            HTML("<br/>"),link)
    
  })
}
