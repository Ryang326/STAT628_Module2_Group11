library(shiny)
library(tidyverse)
library(shinythemes)
library(flexdashboard)
wrist_low <- 15
wrist_up <- 21
height_low <- 100
height_up <- 200
abdomen_low <- 70
abdomen_up <- 120
age_low <- 20
age_up <- 100

css <- HTML("
.html-widget.gauge svg {
  height: 300px;
  width: 400px;
}")

ui <- fluidPage(theme = shinytheme("cerulean"),
                
                titlePanel("Body Fat Calculator - Group 11","Body Fat Calculator - Group 11"),
                tags$head(tags$style(css)),
                sidebarLayout(
                  
                  sidebarPanel(
                    h4("Do you want to know your body fat? \nJust enter the following indicators!"),
                    numericInput("age","AGE:",value = 23, min = 20, max = 80, step = 1),
                    
                    fluidRow(column(width = 7,
                                    numericInput("height","HEIGHT:",value = 172.08, min = height_low, max = height_up)),
                             column(width = 5,
                                    radioButtons("height_unit","Unit",choices = c("cm","inches"),selected = "cm")
                             )),
                    fluidRow(column(width = 7,
                                    numericInput("abdomen","ABDOMEN:",value = 82.5, min = abdomen_low, max = abdomen_up)),
                             column(width = 5,
                                    radioButtons("abdomen_unit","Unit",choices = c("cm","inches"),selected = "cm")
                             )),
                    fluidRow(column(width = 7,
                                    numericInput("wrist","(Optional) WRIST:",value = 17, min = wrist_low, max = wrist_up)),
                             column(width = 5,
                                    radioButtons("wrist_unit","Unit",choices = c("cm","inches"),selected = "cm")
                             )),
                    
                    actionButton("calculate", "Calculate Your Body Fat!", class = "btn-success")
                  ),
                  mainPanel(
                    plotOutput("empty",height = "60px"),
                    splitLayout(cellWidths = c("60%","40%"),
                                gaugeOutput("gauge", height = "300px"),
                                imageOutput("comparison")
                                
                    )
                  )),
                
                span(textOutput("text1"),style = "font-size: 30px;font-weight: bold"),
                span(textOutput("text2"),style = "font-size: 25px;font-weight: bold;color: skyblue")
                
                
)


